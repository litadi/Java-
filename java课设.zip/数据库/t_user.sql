INSERT INTO `t_user`(`id`, `username`, `realname`, `password`, `sex`, `create_time`) VALUES ('69dd8f7a-67ea-4316-9f7f-364823b4fdf6', '123', '倩', 'aodi123', '女', NULL);
INSERT INTO `t_user`(`id`, `username`, `realname`, `password`, `sex`, `create_time`) VALUES ('f9df8aec-6cb0-4da4-8286-889bb8b75e34', 'chenaodi', '陈奥迪', '123456', '男', NULL);
