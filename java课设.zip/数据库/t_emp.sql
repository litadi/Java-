INSERT INTO `t_emp`(`department`, `id`, `name`, `salary`, `age`, `bir`, `official`) VALUES ('销售部', '1', '张三', 2022.00, 18, '6-23', 1);
INSERT INTO `t_emp`(`department`, `id`, `name`, `salary`, `age`, `bir`, `official`) VALUES ('销售部', '3', '王五', 12333.00, 20, '2022/10/17', 1);
INSERT INTO `t_emp`(`department`, `id`, `name`, `salary`, `age`, `bir`, `official`) VALUES ('运营部', '5', '奥迪', 15000.00, 18, '2022-10-17', 1);
