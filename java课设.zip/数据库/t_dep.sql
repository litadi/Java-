INSERT INTO `t_dep`(`department`, `id`) VALUES ('销售部', 2);
INSERT INTO `t_dep`(`department`, `id`) VALUES ('服务部', 4);
INSERT INTO `t_dep`(`department`, `id`) VALUES ('运营部', 5);
INSERT INTO `t_dep`(`department`, `id`) VALUES ('产品研发', 8);
