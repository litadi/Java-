package com.service;

import com.dao.DepDao;
import com.dao.EmpDao;
import com.entity.Dep;
import com.entity.Emp;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;
import tk.mybatis.mapper.entity.Example;

import javax.annotation.Resource;
import java.util.List;

@Service
@Transactional
public class DepServiceImpl implements DepService {
    @Resource
    private DepDao depDAO;
    @Resource
    private EmpDao empDao;

    @Override
    @Transactional(propagation = Propagation.SUPPORTS)
    public List<Dep> findAll() {
        return depDAO.selectAll();
    }

    @Override
    public void save(Dep dep) {
        depDAO.insert(dep);
    }

    @Override
    public void delete(String id) {
        Dep dep = depDAO.selectByPrimaryKey(id);
        Example example = new Example(Emp.class);
        Example.Criteria criteria = example.createCriteria();
        criteria.andEqualTo("department",dep.getDepartment());
        empDao.deleteByExample(example);
        depDAO.deleteByPrimaryKey(id);

    }

    @Override
    @Transactional(propagation = Propagation.SUPPORTS)
    public Dep find(String id) {
        return depDAO.selectByPrimaryKey(id);
    }

    @Override
    public void update(Dep dep) {
        Dep depBefore = depDAO.selectByPrimaryKey(dep.getId());
        Example example = new Example(Emp.class);
        Example.Criteria criteria = example.createCriteria();
        criteria.andEqualTo("department",depBefore.getDepartment());
        List<Emp> emps = empDao.selectByExample(example);
        for (Emp emp : emps) {
            emp.setDepartment(dep.getDepartment());
            empDao.updateByPrimaryKey(emp);
        }

        depDAO.updateByPrimaryKey(dep);
    }

}
