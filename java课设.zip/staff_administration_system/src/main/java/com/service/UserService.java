package com.service;

import com.entity.User;

public interface UserService {
    void register(User user);

    User login(String username, String password);
}
