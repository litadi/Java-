package com.service;

import com.entity.Dep;

import java.util.List;

public interface DepService {
    List<Dep> findAll();

    void save(Dep dep);

    void delete(String id);

    Dep find(String id);

    void update(Dep dep);
}
