package com.service;

import com.dao.EmpDao;
import com.dao.EmpDaoCust;
import com.entity.Emp;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;
import tk.mybatis.mapper.entity.Example;

import javax.annotation.Resource;
import java.util.List;

@Service
@Transactional
public class EmpServiceImpl implements EmpService {

    @Resource
    private EmpDao empDAO;
    @Resource
    private EmpDaoCust empDaoCust;

    @Override
    @Transactional(propagation = Propagation.SUPPORTS)
    public List<Emp> findAll() {
        return empDAO.selectAll();
    }

    @Override
    public List<Emp> findAllFormal() {
        Example example = new Example(Emp.class);
        Example.Criteria criteria = example.createCriteria();
        criteria.andEqualTo("official",1);
        List<Emp> emps = empDAO.selectByExample(example);
        return emps;
    }

    @Override
    public List<Emp> findAllInformal() {
        Example example = new Example(Emp.class);
        Example.Criteria criteria = example.createCriteria();
        criteria.andEqualTo("official",0);
        List<Emp> emps = empDAO.selectByExample(example);
        return emps;
    }

    @Override
    public void save(Emp emp) {
        String id = String.valueOf(empDaoCust.countEmpNum()+1);
        emp.setId(id);
        empDAO.insert(emp);
    }

    @Override
    public void delete(String id) {
        empDAO.deleteByPrimaryKey(id);
    }

    @Override
    @Transactional(propagation = Propagation.SUPPORTS)
    public Emp find(String id) {
        return empDAO.selectByPrimaryKey(id);
    }

    @Override
    public void update(Emp emp) {
        empDAO.updateByPrimaryKey(emp);
    }
}
