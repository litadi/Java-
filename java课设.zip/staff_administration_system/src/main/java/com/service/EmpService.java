package com.service;

import com.entity.Emp;

import java.util.List;

public interface EmpService {
    List<Emp> findAll();

    List<Emp> findAllFormal();

    List<Emp> findAllInformal();

    void save(Emp emp);

    void delete(String id);

    Emp find(String id);

    void update(Emp emp);
}
