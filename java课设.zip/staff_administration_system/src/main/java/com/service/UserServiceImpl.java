package com.service;

import com.dao.UserDao;
import com.entity.User;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import tk.mybatis.mapper.entity.Example;

import javax.annotation.Resource;
import java.util.List;
import java.util.UUID;

@Service
@Transactional
public class UserServiceImpl implements UserService {
    @Resource
    private UserDao userDAO;

    @Override
    public void register(User user) {
        user.setId(UUID.randomUUID().toString());
        userDAO.insert(user);
    }

    @Override
    public User login(String username, String password) {
        Example example = new Example(User.class);
        Example.Criteria criteria = example.createCriteria();
        criteria.andEqualTo("username",username);
        List<User> users = userDAO.selectByExample(example);
        User loginuser = users.get(0);
        if (loginuser.getPassword().equals(password)) {
            return loginuser;
        }
        return null;
    }
}
