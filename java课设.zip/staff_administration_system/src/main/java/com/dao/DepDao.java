package com.dao;

import com.dao.mapper.MyMapper;
import com.entity.Dep;
import org.apache.ibatis.annotations.Mapper;

@Mapper

public interface DepDao extends MyMapper<Dep> {
}