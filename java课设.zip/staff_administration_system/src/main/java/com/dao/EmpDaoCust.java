package com.dao;

import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface EmpDaoCust {
     int avg_sal();
     int countEmpNum();
}

