package com.dao;

import com.dao.mapper.MyMapper;
import com.entity.Emp;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface EmpDao extends MyMapper<Emp> {
}