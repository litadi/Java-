package com.config;

import com.interceptor.myInterceptor;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.InterceptorRegistry;
import org.springframework.web.servlet.config.annotation.ResourceHandlerRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurationSupport;

import javax.annotation.Resource;

@Configuration
public class StaticMvcConfigurer extends WebMvcConfigurationSupport {


    @Resource
    com.interceptor.myInterceptor myInterceptor;

    public void addInterceptors(InterceptorRegistry registry) {
        registry.addInterceptor(myInterceptor)
                .addPathPatterns("/**")
                .excludePathPatterns(
                        "/ems/user/**",
                        "/user/**",
                        "/index/**"
                );
    }


    private static final String[] CLASSPATH_RESOURCE_LOCATIONS = {
            "classpath:/templates/", "classpath:/resources/","classpath:/static/css/","classpath:/static/plugins/adminLTE/css/",
            "classpath:/static/", "classpath:/static/plugins/"};

    @Override
    public void addResourceHandlers(ResourceHandlerRegistry registry) {
        registry.addResourceHandler("/**")
                .addResourceLocations("classpath:/static/")
                .addResourceLocations("classpath:/resources/");
        registry.addResourceHandler("/**")
                .addResourceLocations(CLASSPATH_RESOURCE_LOCATIONS);
        super.addResourceHandlers(registry);
    }
}