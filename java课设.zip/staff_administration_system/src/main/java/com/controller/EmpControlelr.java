package com.controller;

import com.entity.Emp;
import com.entity.User;
import com.service.EmpService;
import com.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import java.util.List;

@Controller
@RequestMapping(value = "/emp")
public class EmpControlelr {

    @Autowired
    private EmpService empService;
    @Autowired
    private UserService userService;
    private Model model;

    @GetMapping(value = "/findAll")
    //find和findAll不是重定向，直接到跳转页面，并且直接跳转classpath下template自带/
    //重定向的话不是从template下，是需要加/的
    //查找不是重定向，不加/；重定向需要加/
    public String findAll(Model model, HttpServletRequest request) {
        List<Emp> allList = empService.findAll();
        model.addAttribute("emps", allList);
        HttpSession session = request.getSession();
        User loginUser = (User) session.getAttribute("loginUser");
        model.addAttribute("loginUser",loginUser);
        return "ems/emplist1";
    }


    @PostMapping(value = "/save")
    public String save(Emp emp) {
        empService.save(emp);
        return "/ems/home";
    }

    @GetMapping(value = "/delete")
    public String delete(String id) {
        empService.delete(id);
        return "/ems/home";

    }

    @GetMapping(value = "/find")
    public String find(String id, Model model) {
        Emp emp = empService.find(id);
        model.addAttribute("emp", emp);
        return "ems/updateEmp";
    }

    @RequestMapping(value = "update")
    public String update(Emp emp) {
        empService.update(emp);
        return "/ems/home";
    }

}
