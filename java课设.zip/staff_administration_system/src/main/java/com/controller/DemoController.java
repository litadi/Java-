package com.controller;

import com.dao.*;
import com.entity.Dep;
import com.entity.Emp;
import com.entity.User;
import com.service.EmpService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.util.ArrayList;
import java.util.List;

@Controller
@ResponseBody
public class DemoController {

    @Resource
    private EmpDao empDao;
    @Resource
    private DepDao depDao;
    @Resource
    private EmpService empService;
    @Resource
    private UserDaoCust userDaoCust;
    @Resource
    private EmpDaoCust empDaoCust;
    @Resource
    private DepDaoCust depDaoCust;

    @GetMapping("/ems/findAllEmp")
    public List<Emp> findAllEmp(Model model) {
        List<Emp> emps = empDao.selectAll();
        model.addAttribute("emps", emps);
        return emps;
    }
    @GetMapping("/ems/findAllFormal")
    public List<Emp> findAllFormal(Model model) {
        List<Emp> emps = empService.findAllFormal();
        model.addAttribute("emps", emps);
        return emps;
    }
    @GetMapping("/ems/findAllInformal")
    public List<Emp> findAllInformal(Model model) {
        List<Emp> emps = empService.findAllInformal();
        model.addAttribute("emps", emps);
        return emps;
    }
    @GetMapping("/ems/findAllDep")
    public List<Dep> findAllDep(Model model) {
        List<Dep> deps = depDao.selectAll();
        model.addAttribute("deps", deps);
        return deps;
    }
    @GetMapping("/emp/findAllDep")
    public List<Dep> findAllDep1(Model model) {
        List<Dep> deps = depDao.selectAll();
        model.addAttribute("deps", deps);
        return deps;
    }
    @RequestMapping(value = "ems/emp/update")
    public String update(Emp emp) {
        empService.update(emp);
        return "redirect:/emp/findAll";
    }
    @GetMapping(value = "/data")
    public List<Integer> data() {
        int userNum = userDaoCust.countUserNum();
        int avgSal = empDaoCust.avg_sal();
        int empNum = empDaoCust.countEmpNum();
        int countnum = depDaoCust.countnum();
        List<Integer> listcount  = new ArrayList<>();
        listcount.add(userNum);
        listcount.add(avgSal);
        listcount.add(empNum);
        listcount.add(countnum);
        return listcount;
    }
    @GetMapping(value = "/dep/data")
    public List<Integer> data1() {
        int userNum = userDaoCust.countUserNum();
        int avgSal = empDaoCust.avg_sal();
        int empNum = empDaoCust.countEmpNum();
        int countnum = depDaoCust.countnum();
        List<Integer> listcount  = new ArrayList<>();
        listcount.add(userNum);
        listcount.add(avgSal);
        listcount.add(empNum);
        listcount.add(countnum);
        return listcount;
    }
    @GetMapping(value = "/emp/loginUserName")
    public String loginusername(HttpServletRequest request, HttpServletResponse response) {
        HttpSession session = request.getSession();
        User loginUser = (User) session.getAttribute("loginUser");
        return loginUser.getRealname();
    }


}
