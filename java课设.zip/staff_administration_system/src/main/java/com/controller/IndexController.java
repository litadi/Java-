package com.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

/**
 * @author huanm
 * <p>
 * thymeleaf所有操作都需要通过controller实现跳转
 */
@Controller
public class IndexController {
    @GetMapping(value = "/index")
    public String toIndex() {
        return "ems/login&regist";
    }

    @GetMapping(value = "/toRegister")
    public String toRegister() {
        return "ems/login&regist";
    }

    @GetMapping(value = "toSave")
    public String toSave() {
        return "ems/addEmp";
    }
    @GetMapping(value = "toSaveDep")
    public String toSaveDep() {
        return "ems/addDep";
    }

}
