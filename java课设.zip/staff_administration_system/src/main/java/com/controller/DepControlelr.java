package com.controller;

import com.dao.DepDaoCust;
import com.entity.Dep;
import com.service.DepService;
import com.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import javax.annotation.Resource;
import java.util.List;

@Controller
@RequestMapping(value = "/dep")
public class DepControlelr {

    @Autowired
    private DepService depService;
    @Autowired
    private UserService userService;
    @Resource
    private DepDaoCust depDaoCust;


    private Model model;


    @GetMapping(value = "/findAll")
    //find和findAll不是重定向，直接到跳转页面，并且直接跳转classpath下tdeplate自带/
    //重定向的话不是从tdeplate下，是需要加/的
    //查找不是重定向，不加/；重定向需要加/
    public String findAll(Model model) {
        List<Dep> allList = depService.findAll();
        model.addAttribute("deps", allList);
        System.out.println(allList);
        return "ems/deplist1";
    }


    @PostMapping(value = "/save")
    public String save(Dep dep) {
        depService.save(dep);
        return "/ems/home";
    }

    @GetMapping(value = "/delete")
    public String delete(String id) {
        depService.delete(id);
        return "/ems/home";
    }

    @GetMapping(value = "/find")
    public String find(String id, Model model) {
        Dep dep = depService.find(id);
        model.addAttribute("dep", dep);
        return "ems/updateDep";
    }

    @RequestMapping(value = "update")
    public String update(Dep dep) {
        depService.update(dep);
        return "/ems/home";
    }

}
