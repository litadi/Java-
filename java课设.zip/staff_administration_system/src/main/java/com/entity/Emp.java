package com.entity;

import javax.persistence.Id;
import javax.persistence.Table;

@Table(name = "t_emp")
public class Emp {
    @Id
    private String id;

    private String department;

    private String name;

    private Double salary;

    private Integer age;

    private String bir;

    private Integer official;

    /**
     * @return id
     */
    public String getId() {
        return id;
    }

    /**
     * @param id
     */
    public void setId(String id) {
        this.id = id;
    }

    /**
     * @return department
     */
    public String getDepartment() {
        return department;
    }

    /**
     * @param department
     */
    public void setDepartment(String department) {
        this.department = department;
    }

    /**
     * @return name
     */
    public String getName() {
        return name;
    }

    /**
     * @param name
     */
    public void setName(String name) {
        this.name = name;
    }

    /**
     * @return salary
     */
    public Double getSalary() {
        return salary;
    }

    /**
     * @param salary
     */
    public void setSalary(Double salary) {
        this.salary = salary;
    }

    /**
     * @return age
     */
    public Integer getAge() {
        return age;
    }

    /**
     * @param age
     */
    public void setAge(Integer age) {
        this.age = age;
    }

    /**
     * @return bir
     */
    public String getBir() {
        return bir;
    }

    /**
     * @param bir
     */
    public void setBir(String bir) {
        this.bir = bir;
    }

    /**
     * @return official
     */
    public Integer getOfficial() {
        return official;
    }

    /**
     * @param official
     */
    public void setOfficial(Integer official) {
        this.official = official;
    }
}